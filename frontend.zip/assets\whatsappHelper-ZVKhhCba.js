const x=`*تحديث بخصوص الطلب*
رقم الطلب: {order_id}
------------------------------
*بيانات صاحب التأشيرة*
الاسم: {visa_holder}
رقم الجواز: {passport_number}
تاريخ الميلاد: {birth_date}
رقم التأشيرة: {visa_number}
------------------------------
*بيانات العميل والعقود*
العميل / المندوب: {delegate_name}
رقم عقد مساند: {contract_number}
رقم عقد التوثيق: {authentication_contract_number}
------------------------------
حالة الطلب: {status}`,h={external:x,client:x,saudi:x},I="https://alserage.alfanar-rec.com",C=t=>{let e=String(t||"").trim().replace(/\D/g,"");if(e.startsWith("00")&&(e=e.slice(2)),e.startsWith("0")){if(e.length===11&&/^01[0125]/.test(e))return`20${e.slice(1)}`;if(e.length===10&&/^05/.test(e))return`966${e.slice(1)}`;e=e.slice(1)}return e},y=(t="saudi")=>{const e=localStorage.getItem("whatsapp_templates");if(e)try{const c=JSON.parse(e)[t],_=((c==null?void 0:c.match(/\{[^}]+\}/g))||[]).length;return c&&c.includes(`
`)&&_>1?c:h[t]}catch{return h[t]}const s=localStorage.getItem("whatsapp_template"),f=((s==null?void 0:s.match(/\{[^}]+\}/g))||[]).length;return s&&s.includes(`
`)&&f>1?s:h[t]},j=t=>String(t||"").replace(/\r\n/g,`
`).replace(/[ \t]+\n/g,`
`).replace(/\n{3,}/g,`

`).trim(),N=(t,e="saudi")=>{const s={...h};try{Object.assign(s,JSON.parse(localStorage.getItem("whatsapp_templates")||"{}"))}catch{}s[e]=t,localStorage.setItem("whatsapp_templates",JSON.stringify(s))},D=({order:t,newStatus:e,orderStatuses:s=[],saudiOffices:f=[],externalOffices:c=[],clients:_=[]})=>{var $,E,P;if(!t)return;const S=e||t.status,W=(($=s.find(n=>String(n.key||n.id)===String(S)))==null?void 0:$.label)||S||"تحديث جديد",l=t.saudi_office||f.find(n=>String(n.id)===String(t.saudi_office_id||t.supplier_id)),a=t.external_office||c.find(n=>String(n.id)===String(t.external_office_id)),i=t.client||_.find(n=>String(n.id)===String(t.client_id)),p=(l==null?void 0:l.mobile)||(l==null?void 0:l.phone)||"",r=(l==null?void 0:l.whatsapp_link)||"";let o=(a==null?void 0:a.phone)||(a==null?void 0:a.mobile)||"";!o&&(a!=null&&a.contacts)&&a.contacts.length>0&&(o=((E=a.contacts[0])==null?void 0:E.phone)||"");const d=(a==null?void 0:a.whatsapp_link)||"",u=(i==null?void 0:i.phone)||t.client_phone||"",L=t.visa_holder_name||((P=i==null?void 0:i.employee)==null?void 0:P.name)||"غير محدد",T=(i==null?void 0:i.name)||"غير محدد",w=n=>j(n).replace(/\{order_id\}/g,t.id||"").replace(/\{visa_holder\}/g,L).replace(/\{delegate_name\}/g,T).replace(/\{visa_number\}/g,t.visa_number||"غير محدد").replace(/\{contract_number\}/g,t.musaned_contract_number||"غير محدد").replace(/\{authentication_contract_number\}/g,t.authentication_contract_number||"غير محدد").replace(/\{auth_contract_number\}/g,t.authentication_contract_number||"غير محدد").replace(/\{passport_number\}/g,t.passport_number||"غير محدد").replace(/\{birth_date\}/g,t.birth_date||"غير محدد").replace(/\{image_url\}/g,t.visa_image?t.visa_image.startsWith("http")?t.visa_image:`${I}/storage/${t.visa_image.replace(/^\/?storage\//,"")}`:"").replace(/\{status\}/g,W),B={external:w(y("external")),client:w(y("client")),saudi:w(y("saudi"))},v=(n,g)=>{if(!n)return;const m=C(n);if(!m){Swal.fire({icon:"warning",title:"رقم الهاتف غير صالح",text:"يرجى مراجعة رقم الهاتف قبل فتح واتساب.",confirmButtonText:"حسنًا"});return}const b=encodeURIComponent(B[g]);window.open(`https://wa.me/${m}?text=${b}`,"_blank","noopener,noreferrer")},A=n=>{n&&window.open(n,"_blank")};if(!(p||o||u||r||d)){Swal.fire({icon:"info",title:"لا توجد أرقام هواتف",text:"لم يتم العثور على أرقام هواتف أو روابط جروبات مسجلة لـ (المكتب السعودي، المكتب الخارجي، أو العميل) لهذا الطلب.",confirmButtonText:"موافق",confirmButtonColor:"#4f46e5",customClass:{popup:"rounded-4 shadow-lg border-0"}});return}Swal.fire({title:"إرسال إشعار عبر الواتساب 📱",html:`
      <div class="text-center mb-3">
        <p class="text-muted small mb-0">اختر جهة الاتصال التي ترغب في إرسال تفاصيل تحديث الطلب <strong>#${t.id}</strong> لها:</p>
      </div>
      <div class="d-flex flex-column gap-3 text-start my-2">
        ${p||r?`
        <div class="border rounded-3 p-2">
          <div class="fw-bold text-dark mb-2 d-flex align-items-center gap-2">
            <span class="fs-4">🇸🇦</span>
            <span>صاحب المكتب السعودي</span>
          </div>
          <div class="d-flex flex-column gap-1">
            ${p?`
            <button id="wa-saudi-btn" type="button" class="btn btn-outline-primary py-2 px-3 rounded-2 d-flex align-items-center justify-content-between w-100">
              <div class="d-flex align-items-center gap-2">
                <span>📱</span>
                <span class="small dir-ltr">${p}</span>
              </div>
              <i class="fa-brands fa-whatsapp text-success fs-5"></i>
            </button>
            `:""}
            ${r?`
            <button id="wa-saudi-group-btn" type="button" class="btn btn-outline-success py-2 px-3 rounded-2 d-flex align-items-center justify-content-between w-100">
              <div class="d-flex align-items-center gap-2">
                <span>👥</span>
                <span class="small">جروب الواتساب</span>
              </div>
              <i class="fa-brands fa-whatsapp text-success fs-5"></i>
            </button>
            `:""}
          </div>
        </div>
        `:""}

        ${o||d?`
        <div class="border rounded-3 p-2">
          <div class="fw-bold text-dark mb-2 d-flex align-items-center gap-2">
            <span class="fs-4">🌍</span>
            <span>المكتب الخارجي</span>
          </div>
          <div class="d-flex flex-column gap-1">
            ${o?`
            <button id="wa-external-btn" type="button" class="btn btn-outline-primary py-2 px-3 rounded-2 d-flex align-items-center justify-content-between w-100">
              <div class="d-flex align-items-center gap-2">
                <span>📱</span>
                <span class="small dir-ltr">${o}</span>
              </div>
              <i class="fa-brands fa-whatsapp text-success fs-5"></i>
            </button>
            `:""}
            ${d?`
            <button id="wa-external-group-btn" type="button" class="btn btn-outline-success py-2 px-3 rounded-2 d-flex align-items-center justify-content-between w-100">
              <div class="d-flex align-items-center gap-2">
                <span>👥</span>
                <span class="small">جروب الواتساب</span>
              </div>
              <i class="fa-brands fa-whatsapp text-success fs-5"></i>
            </button>
            `:""}
          </div>
        </div>
        `:""}

        ${u?`
        <div class="border rounded-3 p-2">
          <div class="fw-bold text-dark mb-2 d-flex align-items-center gap-2">
            <span class="fs-4">👤</span>
            <span>العميل / المندوب</span>
          </div>
          <button id="wa-client-btn" type="button" class="btn btn-outline-primary py-2 px-3 rounded-2 d-flex align-items-center justify-content-between w-100">
            <div class="d-flex align-items-center gap-2">
              <span>📱</span>
              <span class="small dir-ltr">${u}</span>
            </div>
            <i class="fa-brands fa-whatsapp text-success fs-5"></i>
          </button>
        </div>
        `:""}
      </div>
    `,showConfirmButton:!1,showCancelButton:!0,cancelButtonText:"إلغاء",cancelButtonColor:"#64748b",customClass:{popup:"rounded-4 shadow-lg border-0"},didOpen:()=>{var n,g,m,b,k;p&&((n=document.getElementById("wa-saudi-btn"))==null||n.addEventListener("click",()=>{v(p,"saudi"),Swal.close()})),r&&((g=document.getElementById("wa-saudi-group-btn"))==null||g.addEventListener("click",()=>{A(r),Swal.close()})),o&&((m=document.getElementById("wa-external-btn"))==null||m.addEventListener("click",()=>{v(o,"external"),Swal.close()})),d&&((b=document.getElementById("wa-external-group-btn"))==null||b.addEventListener("click",()=>{A(d),Swal.close()})),u&&((k=document.getElementById("wa-client-btn"))==null||k.addEventListener("click",()=>{v(u,"client"),Swal.close()}))}})};export{h as D,N as a,y as g,D as s};
